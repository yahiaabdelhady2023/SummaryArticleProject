import mysql.connector
import bcrypt

def StartConnection():
    try:
        connection = mysql.connector.connect(
        host="127.0.0.1",
        user="root",
        password="1234",
        database="ChatSummaryDatabase"
        )
    except mysql.connector.Error as e:
        print("Failed to connect")
        print(e)

    cursor = connection.cursor(dictionary=True)
    return connection,cursor

connection,cursor=StartConnection()


def CloseConnection(connection,cursor):
    try:
        cursor.close()
        connection.close()
    except mysql.connector.Error as e:
        print("Failed to close both connection and cursor objects")
        print(e)


def FetchOneRow(TableName,column,Target):
    SQL_statement=f"SELECT * FROM {TableName} "  + f"WHERE {column} = %s"
    print(SQL_statement)
    parameters=(Target,)
    try:
        connection,cursor=StartConnection()
        cursor.execute(SQL_statement, parameters)
        result=cursor.fetchone()
        CloseConnection(connection,cursor)
        if result is None:
            return None
        return result
    
    except mysql.connector.Error as e:
        print("FetchOneRow failed")
        print(e)

def FetchAllRow(TableName):
    SQL_statement="SELECT * FROM %s"
    parameters=(TableName,)
    try:
        connection,cursor=StartConnection()
        cursor.execute(SQL_statement, parameters)
        result=cursor.fetchone()
        CloseConnection(connection,cursor)
        if len(result)==0:
            return None
        return result
    
    except mysql.connector.Error as e:
        print("FetchAllRow failed")
        print(e)

def InsertRow(TableName,columns,parameters_to_insert):
    SQL_statement=f"INSERT INTO {TableName} ("
    value_statement=" VALUES ("
    value_statement=value_statement+"".join(["%s," for parameter in columns])
    SQL_statement=SQL_statement+"".join([f"{parameter}," for parameter in columns])
    SQL_statement=SQL_statement[:len(SQL_statement)-1]+")"
    value_statement=value_statement[:len(value_statement)-1]+")"
    final_statement=SQL_statement+value_statement
    try:
        connection,cursor=StartConnection()
        parameters=[]
        for parameter in parameters_to_insert:
            parameters.append(parameter)
        parameters=tuple(parameters)
        print(final_statement,"YES")
        cursor.execute(final_statement, parameters)
        connection.commit()

        #Now returning the permissionList

        SQL_statement="SELECT permission_name FROM PermissionList where role_id_fk_rp=0"
        cursor.execute(SQL_statement)
        permissionList=cursor.fetchall()
        CloseConnection(connection,cursor)
        return permissionList
    except mysql.connector.Error as e:
        print("InsertRow failed")
        print(e)

def Validate_Login_Details(TableName,Email, Password):
    result=FetchOneRow(TableName,"Email",Email)
    if result is None:
        return False
    
    hashedpassword=result["hashed_password"].encode('utf-8')
    if (bcrypt.checkpw(Password.encode('utf-8'), hashedpassword)):
        return True
    return False
    

def ReturnPermissionList(Email):
    print(Email)
    role_id=FetchOneRow("User","Email",Email)
    print(role_id)
    role_id=role_id["role_id_fk"]
    parameter=(role_id,)
    SQL_statement="SELECT permission_name FROM PermissionList where role_id_fk_rp=%s"
    cursor.execute(SQL_statement,parameter)
    permissionList=cursor.fetchall()
    return permissionList
# def UpdateRow(TableName,parameters_to_insert):
#    SQL_statement="""
#     UPDATE Customers
#     SET PostalCode = 00000
#     WHERE Country = 'Mexico'
#     """