from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import DatabaseConnector
from flask_mail import Mail, Message
import VerifyRegisteredAccount
import smtplib, ssl
import classes
import bcrypt

def isValidAccount(Email_Login,Password_Login):
    result=DatabaseConnector.FetchOneRow("User_Table",Email_Login)
    if result is None:
        return False
    else:
        if result["Hashed_Password"]==Password_Login:
            return True
        return False
    

app = Flask(__name__)
app.secret_key = 'we_do_not_hate_you'

@app.route("/Home")
@app.route('/')
def Index():
    if 'Email' in session and 'PermissionList' in session:
        print("Email and PermissionList exists")
        print(session['PermissionList'])
        return render_template('Index.html',PermissionList=session['PermissionList'])
    else:
        return redirect(url_for('Login'))
    


@app.route('/Login', methods=['GET', 'POST'])
def Login():
    return render_template('Login.html')

@app.route('/processLogin', methods=['GET', 'POST'])
def processLogin():

        Email_Login=request.form['Email_Login']
        Password_Login=request.form['Password_Login']


        if DatabaseConnector.Validate_Login_Details("User",Email_Login,Password_Login):
            session["Email"]=Email_Login
            print(Email_Login)
            session["PermissionList"]=DatabaseConnector.ReturnPermissionList(Email_Login)
            session["PermissionList"]=[x["permission_name"] for x in session["PermissionList"]]
            # raise Exception(session["email"],session["PermissionList"])
            return redirect(url_for('Index'))

        else:
            return render_template('Login.html',error=1)

           
@app.route('/Register', methods=['GET', 'POST'])
def Register():
    return render_template('Register.html')

@app.route('/EmailUniqueness', methods=['POST'])
def EmailUniqueness():
    data = request.get_json()
    print(data)
    if data["Email_Login"]=="Yahia@gmail.com":
     response = {"message": "NotValid"}
    else:
     response = {"message": "Valid"}
        
    return jsonify(response)


@app.route('/VerifyEmail', methods=['POST'])
def VerifyEmail():
    user_details=request.get_json()
    verification_code=VerifyRegisteredAccount.GenerateVerificationCode()
    port = 465  # For SSL
    smtp_server = "smtp.gmail.com"
    sender_email = "annoyingchatbotspammerbr@gmail.com"  
    receiver_email = user_details['Email_Login']
    password = "nnuz sobd tqne kihi"
    message= f"""\
Subject: Verification Code

Please use this Verification code below to verify your email address \n
{verification_code}"""

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, message)

    response = {"message": verification_code}
    return jsonify(response)

@app.route('/ProcessRegister', methods=['GET', 'POST'])
def ProcessRegister():
    forename=request.form["Forename_Insert"]
    email=request.form["Email_Insert"]
    password=request.form["Password_Insert"]


    print("Forename",forename)
    print("email",email)
    print("password",password)
    password_bytes = password.encode('utf-8')
    hashed_password = bcrypt.hashpw(password_bytes, bcrypt.gensalt())
    PermissionList=DatabaseConnector.InsertRow("User",["forename","email","hashed_password"],[forename, email, hashed_password])
    session["email"]=email
    print("PermissionList",PermissionList)
    session["PermissionList"]=PermissionList
    
    return redirect(url_for('Index'))


@app.route('/ViewAccounts' ,methods=['GET','POST'])
def ViewAccounts():
    fake_data=[]
    for i in range(100):
        fake_data.append([f"FORENAME{i}",f"EMAIL{i}",f"ROLE{i}"])
    
    page = request.args.get('page', 1, type=int)
    per_page = 5
    total = len(fake_data)
    pages = (total // per_page) + (1 if total % per_page else 0)
    start = (page - 1) * per_page
    end = start + per_page
    paginated_data = fake_data[start:end]
    print(page)
    pages_buttons=page+4
    while pages_buttons>pages:
        pages_buttons-=1
    return render_template("ViewAccounts.html",paginated_data=paginated_data,page=page,pages=pages,pages_buttons=pages_buttons)

@app.route('/ViewDocuments' ,methods=['GET','POST'])
def ViewDocuments():
    articles = [
        {'title': 'Article 1', 'link': '/Documents/article1', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},
        {'title': 'Article 2', 'link': '/Documents/article2', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},
        {'title': 'Article 3', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},
                {'title': 'Article 4', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

        {'title': 'Article 5', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

        {'title': 'Article 6', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

        {'title': 'Article 7', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

        {'title': 'Article 8', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

        {'title': 'Article 9', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

        {'title': 'Article 10', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

        {'title': 'Article 11', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

        {'title': 'Article 12', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

        {'title': 'Article 13', 'link': '/Documents/article3', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

    ]
    page = request.args.get('Documentpage', 1, type=int)
    per_page = 3
    total = len(articles)
    pages = (total//per_page) + (1 if total % per_page else 0)
    start = (page-1)*per_page
    end = start + per_page
    articles = articles[start:end]
    pages_buttons=page+per_page
    if pages_buttons>pages:
        pages_buttons=pages
    return render_template("ViewDocuments.html",articles_cut=articles,pages=pages,pages_buttons=pages_buttons,page=page)
@app.route('/Documents/<articlename>' ,methods=['GET','POST'])
def Document(articlename):
    print(articlename)
    if articlename=="article1":
        articles = [
        {'title': 'Article 1', 'link': '/Documents/article1', 'MiniDescription':'lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag lorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel maglorem ipsum dolor sit amet, consectetur adipiscing elit lobortis   velit   vel mag'},

        ]
        return render_template("Document.html",articles=articles)

@app.route("/Upload",methods=["POST","GET"])
def upload():
    return render_template("Upload.html")
@app.route("/UploadProcess",methods=['GET','POST'])
def UploadProcess():
    file_details=request.get_json()
    file_name,file_extension=file_details["file_name"].split(".")
    print(file_name,file_extension,file_details)
if __name__ == '__main__':
    app.run(debug=True)