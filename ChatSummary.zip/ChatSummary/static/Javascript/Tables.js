document.addEventListener('DOMContentLoaded', (event) => {

    const Table=document.getElementById('AccountsTable');

    console.log(Table.rows)
    number_of_accounts=Table.rows.length
    //starting from index 1 to avoid picking up the header
    for (let index = 1; index < number_of_accounts; index++) {
        current_row=Table.rows[index]
        current_account_role=current_row.cells[2].innerHTML

        if (current_account_role === "Admin"){
            button_to_disable=Table.rows[index].cells[3]
            droplist_to_disable=Table.rows[index].cells[4]
            console.log(button_to_disable.children[0])
            button_to_disable=button_to_disable.children[0].disabled=true;
            droplist_to_disable=droplist_to_disable.children[0].disabled=true;

        }//End of checking whether the current account_role has same or higher privileges than the current user
    }

    const BorderPopMessage=document.getElementById("BorderPopMessage");
    const PopUpMessage=document.getElementById("PopUpMessage");
    const YesMessage=document.getElementById("YesMessage"); 
    const NoMessage=document.getElementById("NoMessage");


    NoMessage.addEventListener('click', function(event){
                
        BorderPopMessage.style.animation="BorderPopMessageAnimation 2s forwards";
        PopUpMessage.style.animation="PopMessageAnimation 2s forwards";

        setTimeout(function() {
            BorderPopMessage.style.display="none";
            PopUpMessage.style.display="none";
            PopUpMessage.style.animation="none";
            BorderPopMessage.style.animation="none";
        }, 1000);

        
    })


    YesMessage.addEventListener('click', function(event){
                

        BorderPopMessage.style.animation="BorderPopMessageAnimation 2s forwards";
        PopUpMessage.style.animation="PopMessageAnimation 2s forwards";

        setTimeout(function() {
            Table.deleteRow(row_to_delete);
            BorderPopMessage.style.display="none";
            PopUpMessage.style.display="none";
            PopUpMessage.style.animation="none";
            BorderPopMessage.style.animation="none";
        }, 1000);

        
    })
    var row_to_delete;
    Table.addEventListener('click', function(event) {
        if (event.target.tagName === "BUTTON") {
            var row=event.target.parentNode.parentNode;
            row_to_delete=row.rowIndex;
            console.log("rowtodelete",row_to_delete)



            BorderPopMessage.style.display="flex";

            PopUpMessage.style.display="block";

            // var row=event.target.parentNode.parentNode;




            


            
        }//End of checking whether the button is clicked
        else{
            // console.log("event",event.target)
            if (event.target.innerHTML=="Forename") {
                SortForename();
            }
            if(event.target.innerHTML=="Role"){
                SortRole();
            }
        }//End of else statement
    }); //End Of Table Click Event

function SortForename(){
    NotSorted=true;
    rows=Table.rows;
    while (NotSorted) {
        change_counter=0;
        for (let i = 1; i < (rows.length-1); i++) {
                if (rows[i].cells[0].innerHTML.toLowerCase()>rows[i+1].cells[0].innerHTML.toLowerCase()) {
                    Table.rows[i].parentNode.insertBefore(Table.rows[i+1],Table.rows[i]);
                    change_counter+=1
                }
        }
        if (change_counter==0) {
            break;
        }
    }

}


function SortRole(){
    NotSorted=true;
    rows=Table.rows;
    while (NotSorted) {
        change_counter=0;
        for (let i = 1; i < (rows.length-1); i++) {
                if (rows[i].cells[2].innerHTML.toLowerCase()>rows[i+1].cells[2].innerHTML.toLowerCase()) {
                    Table.rows[i].parentNode.insertBefore(Table.rows[i+1],Table.rows[i]);
                    change_counter+=1
                }
        }
        if (change_counter==0) {
            break;
        }
    }

}



//Search Bar

const SearchBar =document.getElementById("SearchBar")
console.log("SearchBar",SearchBar)
const rows_to_search=Table.rows
const length_search=rows_to_search.length
SearchBar.addEventListener("keyup",function(event){

    for (let index = 1; index < length_search; index++){
        
        if (rows_to_search[index].cells[0].innerHTML.toLowerCase().startsWith(SearchBar.value.toLowerCase())) {
            console.log(rows_to_search[index])
            rows_to_search[index].style.display="";
        }
        else{
            rows_to_search[index].style.display="none";
        }

1       
    }
})//ends of search bar event handler



const DownloadPDF=document.getElementById("ButtonPDF")

DownloadPDF.addEventListener("click",function(event) {
    console.log("Executing...")
    var TableClone=document.getElementById("AccountsTable").cloneNode(true);
    TableClone.querySelectorAll('.Exclude').forEach(element => element.remove());

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF();
    pdf.autoTable({ html: TableClone });
    pdf.save('Table.pdf');
})





}); //End DOMContentLoaded
