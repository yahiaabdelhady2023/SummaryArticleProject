document.addEventListener('DOMContentLoaded', (event) => {

    const ArticleBox=document.getElementById("ArticleNoHover");
    const WordCount=document.getElementById("WordCount");
    const WordCountSelected=document.getElementById("WordCountSelected");
    const Minimise=document.getElementById("Minimise");

    WordCount.innerHTML="Word Count : "+ArticleBox.innerText.length
    ArticleBox.addEventListener("mouseup", (event) => {
        WordCountSelected.innerText="Word Count Selected : "+window.getSelection().toString().length
    });

    
    Minimise.addEventListener("click", (event) => {
      
    })
    
}); //End DOMContentLoaded