document.addEventListener('DOMContentLoaded', function() {


const Password_Icon=document.getElementById("Password_Icon")
const Password_Login=document.getElementById("Password_Login")

const Email_Login=document.getElementById("Email_Login")
const Forename_Register=document.getElementById("Forename_Register")
const ConfirmPassword_Register=document.getElementById("ConfirmPassword_Register")

const EmailErrorMessage_Login=document.getElementsByClassName("ErrorMessage")[1]
const ForenameErrorMessage_Register=document.getElementsByClassName("ErrorMessage")[2]

const ConfirmPasswordError=document.getElementsByClassName("ErrorMessage")[3]

const PasswordFormatError=document.getElementsByClassName("ErrorMessage")[4]


const ConfirmPassword_Icon=document.getElementById("ConfirmPassword_Icon")


const SubmitButton=document.getElementById("Registerbutton")
function Password_Icon_Handler(password,icon){


    if(password.type ==="password"){
        password.type="text";
        icon.setAttribute("name", "lock-open-alt");

    }
    else{
        password.type="password";
        icon.setAttribute("name", "lock-alt");
    }


}


    if (Password_Icon){
        Password_Icon.addEventListener('click', function() {
            if(Password_Login){
                Password_Icon_Handler(Password_Login,Password_Icon);
            }

        });


    }

    
    else{ console.log("Password ICON does not work properly");}



if (ConfirmPassword_Icon){
    ConfirmPassword_Icon.addEventListener('click', function() {
            if(Password_Login){
                Password_Icon_Handler(ConfirmPassword_Register,ConfirmPassword_Icon);
            }

        });


    }

function Validation_Email(Email_Login){
    if(Email_Login){
        Email_Login.addEventListener('input', function() {

        if(Email_Login.checkValidity()){
            EmailErrorMessage_Login.style.display="none";
            SubmitButton.disabled = false;

        }
        else{
            EmailErrorMessage_Login.style.display="block";
            EmailErrorMessage_Login.innerHTML = "<box-icon name='message-square-error' type='solid'></box-icon> <span>Email Address format is invalid</span>"
            console.log(EmailErrorMessage_Login.innerHTML)
            SubmitButton.disabled = true;

        }
    });
    }
    else{
        console.log("EMAIL VARIABLE DOES NOT WORK")

    }
}

Validation_Email(Email_Login);

function Validation_Forename(Forename){
    if(Forename){


            
        const regex = /^[A-Z][a-z]{2,6}$/;

        if (regex.test(Forename.value)){
            ForenameErrorMessage_Register.style.display="none";
            SubmitButton.disabled = false;

        }
        
        else{
            ForenameErrorMessage_Register.style.display="block";
            SubmitButton.disabled = true;

        }

}
        
}

if (Forename_Register){
Forename_Register.addEventListener('input', function() {

Validation_Forename(Forename_Register);


});
}
const registrationForm=document.getElementById("registrationForm")
console.log("Registration",registrationForm)






function checkPasswordMatch(){
    if (ConfirmPassword_Register.value !== Password_Login.value) {

    ConfirmPasswordError.style.display="block";
    SubmitButton.disabled = true;

    }
    else{
        ConfirmPasswordError.style.display="none";
        SubmitButton.disabled = false;


    }
}


ConfirmPassword_Register.addEventListener('input', checkPasswordMatch);
Password_Login.addEventListener('input', checkPasswordMatch);



function isPasswordValid(){
        console.log("Password_Login.value.length",Password_Login.value.length)
        if (Password_Login.value.length>=4 & Password_Login.value.length<11) {
            PasswordFormatError.style.display="none";
            SubmitButton.disabled = false;

            console.log("Valid password")
        } 
        else {
            PasswordFormatError.style.display="block";
            SubmitButton.disabled = true;

        }
        
}

Password_Login.addEventListener('input', isPasswordValid);

function PasswordStrength(){
    if (PasswordFormatError.style.display=="block"){
        element.style.border = '0.2em solid rgb(15, 171, 1)';

    }
}










function password_strength(){
    password=Password_Login.value
    PasswordStrength=document.getElementById("PasswordStrength");
    weakness_scale=0
    console.log("[optional] Password is Weak\n",password)
    feedback_message="";
    if (!/[A-Z]/.test(password)) 
        {feedback_message=feedback_message+""
            weakness_scale+=1
        }

    if (!/[a-z]/.test(password)) 
        {feedback_message=feedback_message+""
             weakness_scale+=1

        }

    if (!/[0-9]/.test(password)) 
        {feedback_message=feedback_message+""
         weakness_scale+=1

        }

    if (!/[^A-Za-z0-9]/.test(password))
        {feedback_message=feedback_message+""
          weakness_scale+=1

        }
    
    if (password.length<9){
        {feedback_message=feedback_message+""
        weakness_scale+=1

        }

    }
    //check if feedback is empty, if it is empty password is strong
    if (weakness_scale==0){
        console.log("[optional] Password is strong")
        PasswordStrength.style.display="block";
        PasswordStrength.style.backgroundColor="green";
        PasswordStrength.textContent="[optional] Password is strong :)";

        element.style.border = '0.2em solid rgb(15, 171, 1)';
    }
    else{
        if (weakness_scale==1) {
            PasswordStrength.style.backgroundColor="lightgreen";
            PasswordStrength.textContent="[optional] Password is nearly strong ";
            Password_Login.style.border = '0.2em solid lightgreen';

        }
        else if (weakness_scale==2) {
            PasswordStrength.style.backgroundColor="orange";
            PasswordStrength.textContent="[optional] Password is Medium";
            Password_Login.style.border = '0.2em solid orange';
        
        } 

        else {
            PasswordStrength.style.backgroundColor="red";
            Password_Login.style.border = '0.2em solid rgb(232, 50, 22)';

        }
        PasswordStrength.style.display='block';
        
    }
    weakness_scale=0;

    
}//End of Password strength checker 




Password_Login.addEventListener('input', password_strength);



Email_Login.addEventListener('input', function() {
    const name = Email_Login.value;
    fetch('/EmailUniqueness', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({  Email_Login: Email_Login.value,
                                Forename_Register:Forename_Register.value,
                                Password_Login: Password_Login.value
         })
    })
    .then(response => response.json())
    .then(data => {
    
        if (data.message=="NotValid"){
            EmailErrorMessage_Login.style.display="block";
            EmailErrorMessage_Login.textContent="Email has been used before"
            EmailErrorMessage_Login.innerHTML = "<box-icon name='message-square-error' type='solid'></box-icon> <span>Email Address has been used before</span>"
            SubmitButton.disabled = true;
        } 

    })
    .catch(error => console.error('Error:', error));
});






const VerificationForm=document.getElementById('VerificationForm');
const LoginBox=document.getElementsByClassName("LoginBox")[0]
console.log("LoginBox",LoginBox)
var Verification_Code
registrationForm.addEventListener('submit', function(event) {
    event.preventDefault();
    LoginBox.style.animation = 'GoingAway 2s forwards';
    VerificationForm.style.display="block";
    VerificationForm.style.animation = 'MovingFormVerification 4s forwards';

    fetch('/VerifyEmail', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({  Email_Login: Email_Login.value })
    })
    .then(response => response.json())
    .then(data => {
    
       Verification_Code=data.message
       console.log("Verification_Code")
       console.log(Verification_Code)

    })
});

const ResendMessage=document.getElementById("ResendMessage")
ResendMessage.addEventListener('click', function(event) {
    fetch('/VerifyEmail', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({  Email_Login: Email_Login.value })
    })
    .then(response => response.json())
    .then(data => {
    
       Verification_Code=data.message
       console.log("Verification_Code")
       console.log(Verification_Code)

    })
});


const VerificationInputs=document.getElementsByClassName("VerificationInputs")[0]
const VerificationInputs1=document.getElementsByClassName("VerificationInputs")[1]
const VerificationInputs2=document.getElementsByClassName("VerificationInputs")[2]
const VerificationInputs3=document.getElementsByClassName("VerificationInputs")[3]


const VerificationError=document.getElementsByClassName("ErrorMessage")[5]

VerificationInputs.addEventListener('keyup', function(event) {
    console.log("VerificationInputs")
    if (VerificationInputs.value.length==1) {
        VerificationInputs.nextElementSibling.focus();
    }

});



VerificationInputs1.addEventListener('keyup', function(event) {
    console.log("VerificationInputs")
    if (VerificationInputs1.value.length==1) {
        VerificationInputs1.nextElementSibling.focus();
    }

});



VerificationInputs2.addEventListener('keyup', function(event) {
    console.log("VerificationInputs")
    if (VerificationInputs2.value.length==1) {
        VerificationInputs2.nextElementSibling.focus();
    }

    

});


VerificationForm.addEventListener('submit', function(event) {
    event.preventDefault();
    resultant=VerificationInputs.value+VerificationInputs1.value+VerificationInputs2.value+VerificationInputs3.value
    if(resultant===Verification_Code){
        console.log("Matches")
    }
    else{
        console.log("Not matches")
        VerificationError.style.display="block";

    }
    const Forename_Insert=document.getElementById("Forename_Insert")
    const Email_Insert=document.getElementById("Email_Insert")
    const Password_Insert=document.getElementById("Password_Insert")
    Forename_Insert.value=Forename_Register.value
    Email_Insert.value=Email_Login.value
    Password_Insert.value=Password_Login.value
    document.VerificationForm.submit();


});


  }); //End Of Document