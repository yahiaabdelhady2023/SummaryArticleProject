document.addEventListener('DOMContentLoaded', (event) => {
    //Get all variables
    const FileContainer=document.getElementById("UploadFile")
    const SuccessMessage=document.getElementById("SuccessMessage")
    const ErrorMessage=document.getElementById("ErrorMessage")
    const UploadBoxBorder=document.getElementById("UploadBoxBorder");
    const UploadLoader=document.getElementById("UploadLoader");
    const UploadBox=document.getElementById("UploadBox");

    ErrorMessage.style.display="none"
    SuccessMessage.style.display="none"
    UploadLoader.style.display="none"

    function checkformat(FileName){
        ValidList=[".pdf",".txt",".docx"]

        for (let i = 0; i < ValidList.length; i++) {
            if (FileName.endsWith(ValidList[i])){
                return true
            }
        }
        return false

    }
    FileContainer.addEventListener("change", (event) => {
      UploadProcess(FileContainer.files[0]);

    }); //End of FileContainer

    UploadBoxBorder.addEventListener("dragover", (e) => {
        e.preventDefault();
    });//End of UploadBoxBorder DRAGOVER event

    UploadBoxBorder.addEventListener("drop", (e) => {
        e.preventDefault();
        files_received=e.dataTransfer;
        console.log("UploadBoxBorder",files_received.files[0]);
        FileContainer.files=files_received.files
        UploadProcess(FileContainer.files[0]);
    });//End of UploadBoxBorder DRAGOVER event

    function UploadProcess(File){
        console.log("UploadProcess",File)
        FileName=File.name
        console.log("File name is",File.name)
        console.log("File data is",File.type)
        if(checkformat(FileName)){
            SuccessMessage.style.display="block"
            ErrorMessage.style.display="none"
            UploadLoader.style.display="block"
            UploadBoxBorder.style.animationName="BlurBackground"
            UploadBoxBorder.style.backgroundColor="rgb(255, 238, 5)"
            UploadBoxBorder.addEventListener("click",(e) =>{
            e.preventDefault();
            
            });
            FileContainer.type="none"

            SendToBackEnd(File);
        
       }
        else{
            ErrorMessage.style.display="block"
            SuccessMessage.style.display="none"
        }
    } //End of UploadProcess


    function SendToBackEnd(File){
        fetch('/UploadProcess', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({  File_name: File.name,
                                    FileContent: File
             })
        })
    }
}); //End DOMContentLoaded
