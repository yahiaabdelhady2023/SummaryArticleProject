import random

def GenerateVerificationCode():
    list_for_verification_code="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwyz0123456789"
    length_of_verification_code=4
    return "".join([random.choice(list_for_verification_code) for x in range(length_of_verification_code)])

