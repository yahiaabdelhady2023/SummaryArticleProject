class User:
    def __init__(self,forename=None,email=None,password=None):
        self.forename=forename
        self.email=email
        self.password=password
    def SetForename(self,forename):
        self.forename=forename
    def SetEmail(self,email):
        self.email=email
    def SetPassword(self,password):
        self.password=password
    def getAllUserDetails(self):
        return [self.forename,self.email,self.password]
    